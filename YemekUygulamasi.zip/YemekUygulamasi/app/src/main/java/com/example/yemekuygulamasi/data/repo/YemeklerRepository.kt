package com.example.yemekuygulamasi.data.repo

import com.example.yemekuygulamasi.data.datasource.YemeklerDataSource
import com.example.yemekuygulamasi.data.endity.Yemekler

class YemeklerRepository(var yRepo:YemeklerDataSource) {
    suspend fun yemekleriYukle(): List<Yemekler> = yRepo.yemekleriYukle()
}