package com.example.yemekuygulamasi.data.endity

class YemeklerCevap(var yemekler: List<Yemekler>, var success:String) {
}