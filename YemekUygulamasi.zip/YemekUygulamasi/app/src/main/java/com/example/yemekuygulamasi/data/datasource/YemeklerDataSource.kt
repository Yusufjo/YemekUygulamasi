package com.example.yemekuygulamasi.data.datasource

import com.example.yemekuygulamasi.data.endity.Yemekler
import com.example.yemekuygulamasi.retrofit.YemeklerDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
class YemeklerDataSource(var ydao:YemeklerDao) {
    suspend fun yemekleriYukle() : List<Yemekler> = withContext(Dispatchers.IO){
        return@withContext ydao.YemekleriYukle().yemekler
    }
}