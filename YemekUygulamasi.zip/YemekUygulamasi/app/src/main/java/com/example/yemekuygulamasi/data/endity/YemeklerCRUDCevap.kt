package com.example.yemekuygulamasi.data.endity

class YemeklerCRUDCevap(var success:Int,var message:String) {
}